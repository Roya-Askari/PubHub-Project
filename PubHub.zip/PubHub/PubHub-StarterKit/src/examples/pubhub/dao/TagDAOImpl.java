package examples.pubhub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

import examples.pubhub.model.Book;
import examples.pubhub.model.Tag;
import examples.pubhub.utilities.DAOUtilities;
public class TagDAOImpl implements TagDAO {
	
	Connection connection ;	// Our connection to the database
	PreparedStatement stmt; //// We use prepared statements to help protect against SQL injection
//-----------------------------------------------------------------------------
	@Override
	public boolean addTag(Tag tag, Book book) {
		try {
			connection= DAOUtilities.getConnection();
			String sql="Insert into Book_tags values(?,?)";
			stmt= connection.prepareStatement(sql);
			stmt.setString(1, tag.getTagName());
			stmt.setString(2, book.getIsbn13());
			
			// If we were able to add our book to the DB, we want to return true. 
			// This if statement both executes our query, and looks at the return 
		    // value to determine how many rows were changed
			if(stmt.executeUpdate()!=0) {
				System.out.println("The book_tag table is upadated.");
				//List<Tag> tags= retriveAllTagsByIsbn( book.getIsbn13());
				
				return true;
				
			}else
				return false;
		}catch(SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			// We need to make sure our statements and connections are closed, 
			// or else we could wind up with a memory leak
			closeResources();
		
		}
		
	}

		

	//--------------------------------------------------------------------------------
	@Override
	public boolean deleteTag(Tag tag, Book book) {
		
		try {
			connection= DAOUtilities.getConnection();
			String sql="DELETE FROM book_tags WHERE isbn13=? AND tag_name=?";
			stmt= connection.prepareStatement(sql);
			
			stmt.setString(1, book.getIsbn13());
			stmt.setString(2, tag.getTagName());
			
			if(stmt.executeUpdate()!=0) {
				System.out.println("The book_tag table is upadated.");
				//List<Tag> tags= retriveAllTagsByIsbn( book.getIsbn13());
				
				return true;
				
			}else
				return false;
		}catch(SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			// We need to make sure our statements and connections are closed, 
			// or else we could wind up with a memory leak
			closeResources();
		
		}
		
	}
	
	//------------------------------------------------------------------------------
	@Override
	public List<Book> retiveAllBooksByTag(Tag tag){
		List<Book> books = new ArrayList<>();

		try {
			connection = DAOUtilities.getConnection();
			String sql = " SELECT ISBN_13 FROM BOOK_TAGS WHERE TAG_NAME=?";
			stmt = connection.prepareStatement(sql);
			
			stmt.setString(1, tag.getTagName());
			
			ResultSet rs = stmt.executeQuery();
			
			
			
			while (rs.next()) {
				System.out.println("im here1");
				Book book = new Book();
				System.out.println("im here2");
				book.setIsbn13(rs.getString("isbn_13"));
				
				System.out.println("im here3");
				books.add(book);
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources();
		}
		System.out.println("Given tag: " +tag.getTagName() + ".\n\nRelated tags:\n");
		 
		
		return books;
		
	}
	
	//--------------------------------------------------------------------------
	@Override
	public List<Tag> retriveAllTagsByIsbn(String isbn_13) {
		List<Tag> tags = new ArrayList<Tag>();
		
		try {
			connection = DAOUtilities.getConnection();
			String sql = "SELECT *  FROM book_tags WHERE isbn_13=?";
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, isbn_13);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				Tag tag = new Tag();
				
				
				tag.setTagName(rs.getString("tag_name"));
				
				tags.add(tag);
				
			}
			rs.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally {
			closeResources();
		}
		


		
		System.out.println("Given ISBN: " +isbn_13+ ".\n\nRelated tags:\n");
		return tags;
	}
	
	
	
	
	
	
	
	
	//------------------------------------------------------------------------------
	private void closeResources() {
		try {
			if (stmt != null)
				stmt.close();
		} catch (SQLException e) {
			System.out.println("Could not close statement!");
			e.printStackTrace();
		}
		
		try {
			if (connection != null)
				connection.close();
		} catch (SQLException e) {
			System.out.println("Could not close connection!");
			e.printStackTrace();
		}
	}
	

}
