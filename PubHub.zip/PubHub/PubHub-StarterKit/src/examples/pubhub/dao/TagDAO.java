package examples.pubhub.dao;

import java.util.List;

import examples.pubhub.model.Book;
import examples.pubhub.model.Tag;
public interface TagDAO {
	/*
	�	A method to add a tag to a book, given the tag name and a reference to a book (either a Book reference variable or just an ISBN-13)
	�	A method to remove a tag from a book, given the tag name and a reference to a book (either a Book reference variable or just an ISBN-13)
	�	A method to retrieve all tags that have been added to a given book
	�	A method to retrieve all books that have a given tag. Hint: This will require either a SQL JOIN statement or a nested query.
*/
	
	public boolean addTag(Tag tag, Book book);
	public boolean deleteTag(Tag tag, Book book);// Book_Ta
	public List<Tag> retriveAllTagsByIsbn(String isbn_13);
	public List<Book> retiveAllBooksByTag(Tag tag);
}