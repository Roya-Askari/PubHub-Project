package examples.pubhub.model;

public class BookTag {
	
	private String tagName;
	private String isbn13;
	public String getTagName() {
		return tagName;
	}
	public void setTagName(String tagName) {
		this.tagName = tagName;
	}
	public String getIsbn13() {
		return isbn13;
	}
	public void setIsbn13(String isbn13) {
		this.isbn13 = isbn13;
	}
	@Override
	public String toString() {
		return "BookTag [tagName=" + tagName + ", isbn13=" + isbn13 + "]";
	}

}
