package examples.pubhub.model;

public class Tag {
	
	private String tag_Name;
	
	
	public Tag(String tag)
	{
		tag_Name=tag;
	}
	public Tag() {
		tag_Name=null;
	}
	
	public void setTagName(String tag_Name) {
		this.tag_Name= tag_Name;
	}
	
	public String getTagName() {
		return tag_Name;
	}
	@Override
	public String toString() {
		return "Tag [tag_Name=" + tag_Name + "]";
	}
	
}
