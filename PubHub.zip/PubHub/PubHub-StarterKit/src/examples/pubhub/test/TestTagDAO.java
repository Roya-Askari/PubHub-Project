package examples.pubhub.test;

import java.util.List;

import examples.pubhub.dao.TagDAO;
import examples.pubhub.dao.TagDAOImpl;
import examples.pubhub.model.Book;
import examples.pubhub.model.Tag;

public class TestTagDAO {
	
	 public static void main(String[] args){
		    TagDAO dao = new TagDAOImpl();
		    Tag tag1=new Tag("computer");
		    
		    List<Book> list = dao. retiveAllBooksByTag(tag1);

		    for (int i = 0; i < list.size(); i++){
		      Book t = list.get(i);
		      System.out.println(t);
		    }
		  }

}
